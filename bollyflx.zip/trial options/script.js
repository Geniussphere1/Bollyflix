function hideButto() {
  document.getElementById('Mom').style.backgroundColor='transparent';
  document.getElementById('Mom').style.fontSize='23px';
  document.getElementById('Mom').style.height='32px';
  document.getElementById('Mom').style.scale='(1.2)';
  document.getElementById('Mom').innerText = 'Submited';
  document.getElementById('Mom').style.paddingLeft='32px';
  document.getElementById('Mom').style.width='164px';
}

function hideButton() {
 document.getElementById('Mom1').style.backgroundColor='green';
}

// search button 

let query = document.querySelector('.query')
let search = document.querySelector('.search')

search.onclick = function () {
 let url = 'https://www.google.com/search?q='+query.value;
 window.open(url,'_self');
}

//hdhub search

let query1 = document.querySelector('.query1')
let search1 = document.querySelector('.search1')

search1.onclick = function() {
  let urlq = 'https://www.geniussphere.fun/search?q='+query1.value;
  window.open(urlq);
}

// #text

let text = document.getElementById('#text')
let x = function() {
  text.innerHTML = 'love'
  // Tab to edit
};